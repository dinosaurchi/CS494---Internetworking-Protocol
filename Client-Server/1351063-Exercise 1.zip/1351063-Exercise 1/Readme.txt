Student	:	TRAN TINH CHI 
ID		: 	1351063
Class	:	13CTT

This is the tutorial for executing Client-Server Calculator.

1)	Open one terminal window (Linux or MacOS). 
2)	Set the working directory to the "server" directory. 
3)	Type "make" to compile program "server" with gcc
4)	Keep that terminal window.

5)	Open another terminal window (Linux or MacOS). 
6)	Set the working directory to the "client" directory. 
7)	Type "make" to compile program "client" with gcc

8)	The connection is established: 
		Enter 1st number: ...
		Enter 2nd number: ...

	And you will receive the result of Sum, Sub, Mul, Div, Mod from the server.
	
	Note: if you enter non-integer characters, the server will response it as an illegal input. 

	Client and Server are expected to run forever, except when you stop them accidentially.


